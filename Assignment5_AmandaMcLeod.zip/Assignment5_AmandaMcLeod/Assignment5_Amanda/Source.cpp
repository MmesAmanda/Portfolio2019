/*
TITLE ASSIGNMENT 5
AMANDA MCLEOD
OBJECTIVE: MAKE THE HANG MAN GAME 
*/




#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>
#include <Windows.h>

using namespace std;

HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
WORD wOldColorAttrs;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

void PrintMan(int i);
void gotoXY(int x, int y);
int main()
{
	vector<string> Dash;
	srand(time(NULL));
	string temp;

	SetConsoleTextAttribute(h, FOREGROUND_RED);

	cout << "                                                  ___________.._______" << endl;
	cout << "                                                 | .__________))______|" << endl;
	cout << "                                                 | | / /      ||" << endl;
	cout << "                                                 | | / /      ||" << endl;
	cout << "                                                 | | /        ||.-''." << endl;
	cout << "                                                 | |/         |/  _  \\ " << endl;
	cout << "                                                 | |          ||  `/,|" << endl;
	cout << "                                                 | |          (\\\\`_.'" << endl;
	cout << "                                                 | |         .-`--'." << endl;
	cout << "                                                 | |        /Y . . Y\\ " << endl;
	cout << "                                                 | |       // |   | \\\\" << endl;
	cout << "                                                 | |      //  | . |  \\\\" << endl;
	cout << "                                                 | |      //  | . |  \\\\" << endl;
	cout << "                                                 | |          ||'||" << endl;
	cout << "                                                 | |          || ||" << endl;
	cout << "                                                 | |          || ||" << endl;
	cout << "                                                 | |          || ||" << endl;
	cout << "                                                 | |         / | | \\" << endl;
	cout << "                                                 """"""""""|_`-' `-'   ""  " << endl;
	cout << "                                                 |"  """""""\ \        " "|" "" << endl;
	cout << "                                                 | |         \ \          |" << endl;
	cout << "                                                 : :          \ \       : :" << endl;
	cout << "                                                    -WELCOME TO HANGMAN-" << endl;




	int Option;
	SetConsoleTextAttribute(h, 15);
	cout << "                          ****************************** MAINMENU ******************************" << endl;

	cout << "                                                 1 ------- Play ------- 1" << endl;
	cout << "                                                 2 ----- Credits  ----- 2" << endl;
	cout << "                                                 3 -----   Quit  ------ 3" << endl;

	cout << "                          **********************************************************************" << endl;

	cin >> Option;
	if (Option == 1) {

		system("CLS");


		ofstream myOutFile;
		myOutFile.open("Save.txt", ofstream::out | ofstream::app);
		

		ifstream myFile;
		myFile.open("10000CommonMediumWords.txt");

		vector<string> words;
		int wordChoice;
		int bodyPartCounter = 0;



		if (!myFile.fail()) {
			while (!myFile.eof()) {
				getline(myFile, temp);
				words.push_back(temp);
			}
			myFile.close();
		}


		/*for (int i = 0; i < words.size(); i++) {
		cout << words[i] << endl;
		}*/


		wordChoice = rand() % 5460;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0);
		temp = words[wordChoice];
		cout << temp << endl;

		SetConsoleTextAttribute(h, 15);


		int length = temp.length();

		//system("CLS");
		gotoXY(0, 4);
		cout << "                   ************************************GUESS ANY LETTER********************************" << endl;

		gotoXY(45, 6);
		cout << "  ++---------++" << endl;
		gotoXY(45, 7);
		cout << "  ||         ||" << endl;
		gotoXY(45, 8);
		cout << "  ||         ||" << endl;
		gotoXY(45, 9);
		cout << "  ||" << endl;
		gotoXY(45, 10);
		cout << "  ||" << endl;
		gotoXY(45, 11);
		cout << "  ||" << endl;
		gotoXY(45, 12);
		cout << "  ||" << endl;
		gotoXY(45, 13);
		cout << "  ||" << endl;
		gotoXY(45, 14);
		cout << "  ||" << endl;
		gotoXY(45, 15);
		cout << "+===============+" << endl;




		gotoXY(65, 15);
		for (int i = 0; i <= temp.length() - 1; i++)
		{
			Dash.push_back("_ ");
			cout << Dash[i];
		}
		gotoXY(0, 18);
		cout << "                   ************************************************************************************" << endl;


		gotoXY(0, 5);
		cout << "                    YOU HAVE 10 GUESSES";


		char Choice;
		bool check = false;
		vector<char> wrongLetters;

		int counter = 0;
		while (bodyPartCounter < 11)
		{
			check = false;
			//int counter;
			gotoXY(0, 6);
			cout << "                    PLEASE ENTER A LETTER: ";
			cin >> Choice;
			for (int j = 0; j < temp.length(); j++) {
				if (Choice == temp[j]) {
					counter++; 
					Dash[j] = Choice;
					check = true;
				}
	

			}
			if (check == false) {
				bodyPartCounter++;
				PrintMan(bodyPartCounter);
				wrongLetters.push_back(Choice);
				gotoXY(0, 8);
				cout << "                    WRONG LETTERS GUESSED: " << endl;
				gotoXY(20, 9);
				cout << Choice << ", ";
			}

			if (counter == temp.length()) {
				gotoXY(65, 9);
				cout << "YOU WON THE GAME IN "<< counter << " TRIES";
				
				myOutFile << "HANG MAN WORD: " << temp << "\n";
				myOutFile << "PLAYERS HIGHSCORE:" << counter << "\n";
				myOutFile.close();

				Sleep(2000);
				exit(0);
			}
			

			gotoXY(65, 15);
			for (int i = 0; i < length; i++)
			{

				cout << Dash[i] << " ";
			}

			gotoXY(20, 9);
			for (int i = 0; i < wrongLetters.size(); i++) {
				cout << wrongLetters[i] << ", ";
			}

		}

		

		gotoXY(0, 25);
		system("pause");
	}


	else if (Option == 2) {



		cout << "                          **********************************************************************" << endl;
		cout << "                                               Programming by Amanda McLeod" << endl;
		cout << "                                                   Thanks for playing!" << endl;
		cout << "                          **********************************************************************" << endl;

		Sleep(1000);

		system("pause");
	}
}

void PrintMan(int i)
{

	if (i == 1)
	{
		gotoXY(56, 9);
		cout << "   O";
	}
	if (i == 2)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "   |" << endl;
		gotoXY(56, 11);
		cout << "   |" << endl;
	}
	if (i == 3)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "   |\\" << endl;
		gotoXY(56, 11);
		cout << "   | \\" << endl;
	}
	if (i == 4)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
	}
	if (i == 5)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "  /" << endl;
	}
	if (i == 6)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "  / \\" << endl;

	}
	if (i == 7)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "*    " << endl;
		gotoXY(56, 13);
		cout << "  / \\" << endl;

	}
	if (i == 8)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "*     *" << endl;
		gotoXY(56, 13);
		cout << "  / \\" << endl;

	}
	if (i == 9)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "*     *" << endl;
		gotoXY(56, 13);
		cout << "  / \\" << endl;
		gotoXY(56, 14);
		cout << "*    " << endl;
	}
	if (i == 10)
	{
		gotoXY(56, 9);
		cout << "   O";
		gotoXY(56, 10);
		cout << "  /|\\" << endl;
		gotoXY(56, 11);
		cout << " / | \\" << endl;
		gotoXY(56, 12);
		cout << "*     *" << endl;
		gotoXY(56, 13);
		cout << "  / \\" << endl;
		gotoXY(56, 14);
		cout << "*     *" << endl;

		gotoXY(0, 11);
		cout << "                    YOU'VE HUNG YOUR MAN";
		Sleep(2000);
		exit(0);
	}

}


void gotoXY(int x, int y) {
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
